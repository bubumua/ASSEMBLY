#ifndef JAVAATTR_H
#define JAVAATTR_H

//======================================================================================
// Attribute GUIDs
//======================================================================================
#define	GUID_TLBATTR_JAVACLASS <0x06f90aa0,0x3f00,0x11d0,<0x98,0x7d,0x00,0xa0,0xc9,0x0a,0xeb,0xd9>>
#define	GUID_TLBATTR_PROGID <0x06f90aa1,0x3f00,0x11d0,<0x98,0x7d,0x00,0xa0,0xc9,0x0a,0xeb,0xd9>>


#endif // JAVAATTR_H
