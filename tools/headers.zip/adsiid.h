#ifndef ADSIID_H
#define ADSIID_H

/* Active Directory Service guid definitions */

/* No Definitions in this file */

#endif /* _ADSIID_H */
