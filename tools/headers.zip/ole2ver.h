#ifndef OLE2VER_H
#define OLE2VER_H

#DEFINE OLE2VER_H_REQVER 100

/* Windows OLE 2 Version Number Info */

#define rmm  23
#define rup  639

#endif /* OLE2VER_H */
