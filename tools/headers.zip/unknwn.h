#ifndef UNKNWN_H
#define UNKNWN_H

// This is a place holder for the file, it is included for compatibility
// with previous versions of the headers only. The definitions from this
// file have been rolled into BaseCOM.h

#IFNDEF BASECOM_H
	#include "BaseCOM.h"
#ENDIF

#endif /* _UNKNWN_H */

