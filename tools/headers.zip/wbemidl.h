#ifndef WBEMIDL_H
#define WBEMIDL_H

/* WBEM interfaces definitions */
#IFNDEF WBEMCLI_H
	#include wbemcli.h
#ENDIF
#IFNDEF WBEMPROV_H
	#include wbemprov.h
#ENDIF
#IFNDEF WBEMTRAN_H
	#include wbemtran.h
#ENDIF
#IFNDEF WBEMDISP_H
	#include wbemdisp.h
#ENDIF

#endif /* _WBEMIDL_H */
