// This is a part of the Active Template Library.
// Copyright (C) 1996-1998 Microsoft Corporation
// All rights reserved.

#ifndef ATLDEF_H
#define ATLDEF_H

/////////////////////////////////////////////////////////////////////////////
// Master version numbers

#define _ATL     1      // Active Template Library
#define _ATL_VER 0x0300 // Active Template Library version 3.0

#endif // ATLDEF_H
