#ifndef SCHNLSP_H
#define SCHNLSP_H

/* SCHANNEL Security Provider definitions */
#IFNDEF SCHANNEL_H
	#include schannel.h
#ENDIF

#endif /* _SCHNLSP_H */
