///////////////////////////////////////////////////////////////////////////////
//
//  File:  Wpc.h
//
//  Comments:
//      This file defines the Windows Parental Controls interfaces and events
//
//  Copyright (C) 2005 Microsoft Corporation  All Rights Reserved.
//
///////////////////////////////////////////////////////////////////////////////
#IFNDEF WPC_H
#DEFINE WPC_H

#include "WpcApi.h"
#include "WpcEvent.h"

#ENDIF


