#ifndef STDDEF_H
#define STDDEF_H

/* stddef.h - C99 standard header */

#ifndef NULL
	#define NULL 0
#endif

#endif /* _STDDEF_H */


