#ifndef STDBOOL_H
#define STDBOOL_H

/* stdbool.h - C99 standard header */

#IFNDEF false
	#define false  0
#ENDIF
#IFNDEF true
	#define true  1
#ENDIF

#IFNDEF FALSE
	#define FALSE  0
#ENDIF

#IFNDEF TRUE
	#define TRUE  1
#ENDIF

#endif /* _STDBOOL_H */
