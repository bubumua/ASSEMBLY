#ifndef STDARG_H
#define STDARG_H

/* stdarg.h - C99 standard header */

/*
No Definitions
*/

#endif /* _STDARG_H */

