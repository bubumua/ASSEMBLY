#ifndef ACTIVEDS_H
#define ACTIVEDS_H

#IFNDEF IADS_H
	#include "iads.h"
#ENDIF

#IFNDEF ADSERR_H
	#include "adserr.h"
#ENDIF

#IFNDEF ADSSTS_H
	#include "adssts.h"
#ENDIF

#IFNDEF ADSNMS_H
	#include "adsnms.h"
#ENDIF

#IFNDEF ADSDB_H
	#include "adsdb.h"
#ENDIF

#endif /* ACTIVEDS_H */
