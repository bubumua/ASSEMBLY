#ifndef ADSDB_H
#define ADSDB_H

#define DBPROPFLAGS_ADSISEARCH  0000C000h

#endif /* ADSDB_H */
