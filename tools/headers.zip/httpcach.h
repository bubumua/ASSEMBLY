#ifndef HTTPCACH_H
#define HTTPCACH_H

#define URI_CACHE_NAME L"URI"
#define FILE_CACHE_NAME L"FILE"
#define TOKEN_CACHE_NAME L"TOKEN"

#endif


