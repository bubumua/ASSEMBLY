#ifndef CGUID_H
#define CGUID_H

/*
No Definitions
*/

#endif /* _CGUID_H */
