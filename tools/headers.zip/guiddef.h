#ifndef GUIDDEF_H
#define GUIDDEF_H

/* Windows GUID definitions */

/* No definitions */

#endif /* _GUIDDEF_H */

