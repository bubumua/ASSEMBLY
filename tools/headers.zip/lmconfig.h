#ifndef LMCONFIG_H
#define LMCONFIG_H

/* NetConfig API definitions */

#define REVISED_CONFIG_APIS

CONFIG_INFO_0 STRUCT
	cfgi0_key PTR
	cfgi0_data PTR
ENDS

#endif /* _LMCONFIG_H */
