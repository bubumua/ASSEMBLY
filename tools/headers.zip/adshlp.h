#ifndef ADSHLP_H
#define ADSHLP_H

/* Active Directory Service helper definitions */

#IFDEF LINKFILES
	#dynamiclinkfile Activeds.dll
#ENDIF

#endif /* _ADSHLP_H */
