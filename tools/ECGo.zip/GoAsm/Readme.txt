After unzipping ECGo.zip, the 'GoAsm' folder will be created.
Please immediately download the 'GoAsm Headers' at:

http://www.donkeysstable.com

and place them in the 'Include' subfolder (which is empty) of
the 'GoAsm' folder created by unzipping the ECGo.zip package.
Otherwise, Easy Code will not be able to build GOASM projects.

Thanks!
